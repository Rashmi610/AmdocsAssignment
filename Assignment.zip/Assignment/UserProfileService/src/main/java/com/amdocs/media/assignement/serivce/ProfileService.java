package com.amdocs.media.assignement.serivce;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amdocs.media.assignement.dao.UserProfileRepository;

import com.amdocs.media.assignement.model.ProfileModel;
@Transactional
@Service
public class ProfileService {
	@Autowired
	UserProfileRepository userProfileRepository;

	@PersistenceContext	
	private EntityManager entityManager;	
	
	
	private static final Logger logger = LoggerFactory.getLogger(ProfileService.class);
	
	public ProfileModel addProfile(ProfileModel newProfile) {
		// TODO Auto-generated method stub
		 
		ProfileModel create=  userProfileRepository.save(newProfile);
		logger.info("Created new Profile data");
		return create;
		 
		
	}

	public ProfileModel updateProfile(ProfileModel newProfile) {
		// TODO Auto-generated method stub
		
		ProfileModel update=getprofilebyUname(newProfile.getUsername());
		update.setPhoneNo(newProfile.getPhoneNo());
		update.setAddress(newProfile.getAddress());
		entityManager.flush();
		logger.info("Updated Profile data");
		return newProfile;
	}

	

	public List<ProfileModel> getAllprofileInfo() {
		 List<ProfileModel> list =new ArrayList<>();
		 userProfileRepository.findAll().forEach(list::add);
		 return list;
	}
	
	public ProfileModel getprofilebyUname(String newProfile) {
		ProfileModel profileobj=userProfileRepository.getByUname(newProfile);
		
		return profileobj;
	}

	public ProfileModel deleteProfile(String uname) {
		ProfileModel delProfile=userProfileRepository.getByUname(uname);
		userProfileRepository.delete(delProfile);
		logger.info("Deleted Profile data");
		return delProfile;
	}

	
	

}
