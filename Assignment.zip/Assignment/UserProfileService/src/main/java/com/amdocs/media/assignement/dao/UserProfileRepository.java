package com.amdocs.media.assignement.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.amdocs.media.assignement.model.ProfileModel;


@Repository
public interface UserProfileRepository extends CrudRepository<ProfileModel, Long>{
	@Query(value = "delete  FROM Profile WHERE Username=?1 ", nativeQuery = true)
	ProfileModel deletebyUname(String uname);

	
	@Query(value = "select * FROM Profile WHERE Username=?1 ", nativeQuery = true)
	ProfileModel getByUname(String username);

}
