package com.amdocs.media.assignement.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="Profile")
public class ProfileModel {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@Column(name="phoneNo")
	private long phoneNo;
	
	@Column(name="address")
	private String address;
	
	
	 @Column(name="username",unique = true) 
	 private String username;
	 
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	  public String getUsername()
	  { 
		  return username;
	  }
	  
	  public void setUsername(String username)
	  { 
		  this.username = username; 
	  }

	


	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}



}
