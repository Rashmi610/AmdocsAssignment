package com.amdocs.media.assignement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.amdocs.media.assignement.model.ProfileModel;
import com.amdocs.media.assignement.serivce.ProfileService;

@RestController

public class ProfileController {
	
	@Autowired
	ProfileService profileService;
	
	//Create user Profile
	 @PostMapping("/{uname}") 
	 ProfileModel createProfile(@RequestBody ProfileModel newProfile,@PathVariable ("uname") String uname)
	 {
		  
		 newProfile.setUsername(uname);
		  
		 return profileService.addProfile(newProfile);
					  
	 }
	 
	 //Update Profile
	 @PutMapping("/{uname}")
	 ProfileModel updateProfile(@RequestBody ProfileModel newProfile,@PathVariable ("uname") String uname)
	 {
		
		
			  return profileService.updateProfile(newProfile);
					  
	 }
	 
	 //Delete Profile
	 @DeleteMapping("{uname}")
	 ProfileModel deleteProfile(@PathVariable ("uname") String uname) 
	 {
		 
		 return profileService.deleteProfile(uname);
	 }
	 
	 
	
	 
	 @GetMapping(value = "/getProfile") 
		public List<ProfileModel> getAllProfile()
	 {
			
			return profileService.getAllprofileInfo();
	 }
	
	

}
