package com.amdocs.media.assignement.controller;

import java.util.Arrays;
import java.util.List;

import javax.websocket.server.PathParam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.amdocs.media.assignement.dao.AuthorizationRepository;
import com.amdocs.media.assignement.model.Login;
import com.amdocs.media.assignement.model.ProfileResponse;

import com.amdocs.media.assignement.service.AutherizationService;

@RestController
@RequestMapping(value = "/assignement")
public class AuthorizationServiceController {
	@Autowired
	public AutherizationService autherizationService;
	
	 @Autowired
	 public RestTemplate restTemplate;
	
	
	 boolean loginCheck=false;
	
	 //Method for creating Authorization service details
	  @PostMapping("/login") 
	  Login createLoginInfo(@RequestBody Login newLogin)
	  {
	  
	  return autherizationService.addLoginInfo(newLogin);
	  
	  }
	  
	  //Method for creating Profile and Authorization details
	  @PostMapping("/profile") 
	  public ProfileResponse createprofile(@RequestBody ProfileResponse newLogin) 
	  {
		  Login login=new Login();
		  login.setUsername(newLogin.getUsername());
		  login.setPassword(newLogin.getPassword());
		  createLoginInfo(login);
		  
		  String uname=login.getUsername();
		  String pass=login.getPassword();
		  newLogin.setPassword(pass);
		  
		  HttpHeaders headers = new HttpHeaders();
		  HttpEntity<ProfileResponse> entity = new HttpEntity<ProfileResponse>(newLogin,headers);
		  return restTemplate.exchange("http://localhost:9091"+uname,HttpMethod.POST,entity, ProfileResponse.class).getBody();
		
	   }
	  
	  
	  //Update Profile
	 @PutMapping(value = "/{uname}/{pass}")
	  public ProfileResponse updateProfile(@PathVariable ("uname") String uname,@PathVariable ("pass") String pass,@RequestBody ProfileResponse newLogin)
	  {
		  HttpHeaders headers = new HttpHeaders();
		  HttpEntity<ProfileResponse> entity = new HttpEntity<ProfileResponse>(newLogin,headers);
		  Login Obj= autherizationService.getLoginvalidate(uname, pass);
		  String username=Obj.getUsername();
		  
		  ProfileResponse responseObj= restTemplate.exchange("http://localhost:9091"+username,HttpMethod.PUT,entity, ProfileResponse.class).getBody();
		  return responseObj;
		  
		  
	  }
	 
	//Delete Profile
	@DeleteMapping(value = "/{uname}/{pass}")
	  public ProfileResponse deleteProfile(@PathVariable ("uname") String uname,@PathVariable ("pass") String pass,@RequestBody ProfileResponse newLogin)
	  {
		  HttpHeaders headers = new HttpHeaders();
		  HttpEntity<ProfileResponse> entity = new HttpEntity<ProfileResponse>(newLogin,headers);
		  Login loginObj= autherizationService.getLoginvalidate(uname, pass);
		  String username=loginObj.getUsername();
		  
		  ProfileResponse responseObj= restTemplate.exchange("http://localhost:9091"+username,HttpMethod.DELETE,entity, ProfileResponse.class).getBody();
		  return responseObj;
		  
		  
	  }
	 
	
	//For my Reference
	
	@GetMapping(value = "/getlogin") 
	public List<Login> getAllLoginInfo()
	{
		
		return autherizationService.getAllLoginInfo();
	}
	
	
	@GetMapping(value = "get/{uname}/{pass}") 
	public ResponseEntity<Object>  getLoginInfoByUnamePass(@PathVariable ("uname") String uname,@PathVariable ("pass") String pass) {
		
	Login Obj= autherizationService.getLoginvalidate(uname,pass);
	if(Obj!=null) {
		loginCheck=true;
		 return new ResponseEntity<>("Validation Successful", HttpStatus.OK);
	}else {
		
		System.out.println("Validation Failed");
		 return new ResponseEntity<>("Validation Failed", HttpStatus.OK);
	}
	
	
	}
	
	
	
	
	 	
	
	
	 	
}
