package com.amdocs.media.assignement.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdocs.media.assignement.dao.AuthorizationRepository;
import com.amdocs.media.assignement.model.Login;

@Service
public class AutherizationService {
	
	@Autowired
	public AuthorizationRepository authorizationRepository;
	
	
	public List<Login> getAllLoginInfo()
	{
		
		List<Login> Loginlist =new ArrayList<>();
		authorizationRepository.findAll().forEach(Loginlist::add);
		 
		return Loginlist;
		
		}
	
	
	public Login addLoginInfo(Login logindetails)
	{
		
		Login loginObj= authorizationRepository.save(logindetails);
		return loginObj;
	}

	
	  public Login getLoginvalidate(String uname, String pass) 
	  {
	  
	  Login loginCredentials=authorizationRepository.findvalidation(uname,pass); 
	  return loginCredentials;
	  
	  }
	 
	
	public Login getLoginInfobyUnamePass(String uname) {
		
		Login loginCredentials=authorizationRepository.findUnamePass(uname);
		return loginCredentials;
	}
	
	

}
