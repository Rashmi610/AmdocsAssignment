package com.amdocs.media.assignement.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.amdocs.media.assignement.model.Login;

@Repository
public interface AuthorizationRepository extends CrudRepository<Login, String>{
	
	@Query(value = "SELECT * FROM authorizationservice WHERE Username=?1", nativeQuery = true)
	Login findUnamePass(String uname);
	
	
	@Query(value = "SELECT * FROM authorizationservice WHERE Username=?1 and Password=?2", nativeQuery = true)
	Login findvalidation(String uname, String pass);
	
	

}
